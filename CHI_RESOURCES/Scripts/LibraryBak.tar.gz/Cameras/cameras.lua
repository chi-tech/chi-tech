chilActiveCamera = {};

chilActiveCamera.object = nil
chilActiveCamera.callbackFunction = function ()
--print("Hello")
end

chilCamera = {}
chilCamera.itemCount = 0;

chilCamera.AddCamera = function (cameraObj)
    chilCamera.itemCount = chilCamera.itemCount+1;
    local index = chilCamera.itemCount;
    chilCamera[index] = cameraObj;
end


function chilSetActiveCamera(newCamera)
    chilActiveCamera.callbackReference = newCamera;
    chilActiveCamera.callbackFunction  = newCamera.callbackFunction;
end

newCallback = chilCallbacks.MakeCallback(chilActiveCamera);
chilCallbacks.PushCallback(newCallback);