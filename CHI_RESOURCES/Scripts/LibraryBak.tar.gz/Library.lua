chiLibraryRoot = "CHI_RESOURCES/Scripts/chil/"

--===================================== UtilityFunctions
dofile(chiLibraryRoot.."Callbacks.lua")
dofile(chiLibraryRoot.."chi_Nteractor/chin_GlobalFunctions/chin_globalfs_getscriptpath.lua")


--===================================== Cameras
dofile(chiLibraryRoot.."Cameras/cameras.lua")
dofile(chiLibraryRoot.."Cameras/CHI_CAMERA_THIRDPERSON.lua")

--===================================== Default Material
chiDefaultMat  = chiMaterialCreate()


--===================================== Default light


--===================================== World items
CHI_WORLD_DEFAULTFLOOR = chiLibraryRoot.."WorldItems/CHI_WORLD_DEFAULTFLOOR.lua"



--===================================== Defining the main function
function main()
    chilCallbacks.Execute()
end

print("Library loaded")